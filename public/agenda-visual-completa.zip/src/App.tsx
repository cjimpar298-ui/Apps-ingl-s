import { useState, useEffect, useRef, ChangeEvent } from 'react';
import { 
  Plus, 
  Trash2, 
  X, 
  Check, 
  ChevronLeft, 
  ChevronRight, 
  Edit2, 
  RotateCcw, 
  Palette, 
  LayoutGrid, 
  Clock, 
  PartyPopper, 
  Upload, 
  CheckCircle2, 
  Circle,
  Download,
  FileArchive,
  AlertCircle,
  Info,
  Sparkles,
  Layers,
  HelpCircle,
  Play,
  Calendar,
  Save,
  BookmarkCheck,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import {
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  rectSortingStrategy,
} from '@dnd-kit/sortable';

import { 
  Activity, 
  ActivityType, 
  Theme, 
  VisualAgendaV3Data, 
  VisualAgendaV4Data, 
  ClassSession, 
  ToastNotification, 
  GRADES, 
  Grade,
  STANDARD_GREETINGS
} from './types';
import { PREDEFINED_ACTIVITY_TYPES, DEFAULT_INITIAL_ACTIVITIES } from './data/activityTypes';
import { formatSpanishDate, getTodayDateString } from './lib/dateUtils';
import { SortableActivityCard } from './components/ActivityCard';
import { SortableSequenceItem } from './components/SortableSequenceItem';
import { ActivityModal } from './components/ActivityModal';
import { ActivityTypesModal } from './components/ActivityTypesModal';
import { SessionActivityPickerModal } from './components/SessionActivityPickerModal';
import { SessionConfigCard } from './components/SessionConfigCard';
import { SessionsModal } from './components/SessionsModal';
import { ThemeModal, THEMES } from './components/ThemeModal';
import { ActivityIconBadge, IconRenderer } from './components/IconRenderer';

function normalizeGrade(raw: string | undefined): Grade {
  if (!raw) return '1.º EP';
  const trimmed = raw.trim();
  if (trimmed.includes('1')) return '1.º EP';
  if (trimmed.includes('2')) return '2.º EP';
  if (trimmed.includes('3')) return '3.º EP';
  if (trimmed.includes('4')) return '4.º EP';
  if (trimmed.includes('5')) return '5.º EP';
  if (trimmed.includes('6')) return '6.º EP';
  return '1.º EP';
}

function createInitialActivitiesByGrade(): Record<string, Activity[]> {
  const result: Record<string, Activity[]> = {};
  GRADES.forEach(grade => {
    result[grade] = DEFAULT_INITIAL_ACTIVITIES.map(act => ({
      ...act,
      id: `${grade.replace(/[^a-zA-Z0-9]/g, '')}-${act.id}`
    }));
  });
  return result;
}

export default function App() {
  const [view, setView] = useState<'setup' | 'class'>('setup');
  const [selectedGrade, setSelectedGrade] = useState<Grade>('4.º EP');
  const [title, setTitle] = useState('English Lesson Routine & Activities');
  const [plannedDate, setPlannedDate] = useState<string>(getTodayDateString());
  const [ls, setLs] = useState<string>('LS 1');
  const [greeting, setGreeting] = useState<string>('GOOD MORNING CLASS!');
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);

  const [activitiesByGrade, setActivitiesByGrade] = useState<Record<string, Activity[]>>(createInitialActivitiesByGrade);
  const [activityTypes, setActivityTypes] = useState<ActivityType[]>(PREDEFINED_ACTIVITY_TYPES);
  const [sequence, setSequence] = useState<Activity[]>([]);
  const [completedIds, setCompletedIds] = useState<Set<string>>(new Set());
  const [sessions, setSessions] = useState<ClassSession[]>([]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [theme, setTheme] = useState<Theme>(THEMES[0]);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Modals
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
  const [isActivityTypesModalOpen, setIsActivityTypesModalOpen] = useState(false);
  const [isSessionPickerOpen, setIsSessionPickerOpen] = useState(false);
  const [isSessionsModalOpen, setIsSessionsModalOpen] = useState(false);
  const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  const showToast = (
    message: string, 
    type: 'success' | 'error' | 'info' = 'info',
    actionLabel?: string,
    onAction?: () => void
  ) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    setToasts(prev => [...prev, { id, type, message, actionLabel, onAction }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, actionLabel ? 6500 : 3800);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Persistence and Auto-migration on initial mount (v4 -> v3 -> v2)
  useEffect(() => {
    try {
      // 1. First priority: Load existing v4 data
      const v4Saved = localStorage.getItem('visual-agenda-v4');
      if (v4Saved) {
        const data = JSON.parse(v4Saved);
        if (data && data.schemaVersion === 4 && data.activitiesByGrade) {
          const initialMap = createInitialActivitiesByGrade();
          GRADES.forEach(g => {
            if (Array.isArray(data.activitiesByGrade[g])) {
              initialMap[g] = data.activitiesByGrade[g];
            }
          });
          setActivitiesByGrade(initialMap);
          if (data.selectedGrade) setSelectedGrade(normalizeGrade(data.selectedGrade));
          if (Array.isArray(data.sequence)) setSequence(data.sequence);
          if (typeof data.title === 'string') setTitle(data.title);
          if (typeof data.plannedDate === 'string') setPlannedDate(data.plannedDate);
          if (typeof data.ls === 'string') setLs(data.ls);
          if (typeof data.greeting === 'string') setGreeting(data.greeting);
          if (typeof data.currentSessionId === 'string') setCurrentSessionId(data.currentSessionId);
          if (Array.isArray(data.sessions)) setSessions(data.sessions);
          if (data.themeId) {
            const found = THEMES.find(t => t.id === data.themeId);
            if (found) setTheme(found);
          }
          if (Array.isArray(data.activityTypes) && data.activityTypes.length > 0) {
            const existingIds = new Set(data.activityTypes.map((t: ActivityType) => t.id));
            const merged = [...data.activityTypes];
            PREDEFINED_ACTIVITY_TYPES.forEach(pt => {
              if (!existingIds.has(pt.id)) {
                merged.push(pt);
              }
            });
            setActivityTypes(merged);
          }
          return;
        }
      }

      // 2. Migration: If no v4, check for v3 data and migrate seamlessly (v3 is left intact)
      const v3Saved = localStorage.getItem('visual-agenda-v3');
      if (v3Saved) {
        const data = JSON.parse(v3Saved);
        if (data && data.schemaVersion === 3 && data.activitiesByGrade) {
          const initialMap = createInitialActivitiesByGrade();
          GRADES.forEach(g => {
            if (Array.isArray(data.activitiesByGrade[g])) {
              initialMap[g] = data.activitiesByGrade[g];
            }
          });
          setActivitiesByGrade(initialMap);
          if (data.selectedGrade) setSelectedGrade(normalizeGrade(data.selectedGrade));
          if (Array.isArray(data.sequence)) setSequence(data.sequence);
          if (typeof data.title === 'string') setTitle(data.title);
          if (data.themeId) {
            const found = THEMES.find(t => t.id === data.themeId);
            if (found) setTheme(found);
          }
          if (Array.isArray(data.activityTypes) && data.activityTypes.length > 0) {
            const existingIds = new Set(data.activityTypes.map((t: ActivityType) => t.id));
            const merged = [...data.activityTypes];
            PREDEFINED_ACTIVITY_TYPES.forEach(pt => {
              if (!existingIds.has(pt.id)) {
                merged.push(pt);
              }
            });
            setActivityTypes(merged);
          }
          setSessions([]);
          return;
        }
      }

      // 3. Migration: If no v3 or v4, check for v2 data
      const v2Saved = localStorage.getItem('visual-agenda-v2');
      if (v2Saved) {
        const v2Data = JSON.parse(v2Saved);
        const migratedGrade = normalizeGrade(v2Data.level || '4.º EP');
        const initialMap = createInitialActivitiesByGrade();

        if (Array.isArray(v2Data.library) && v2Data.library.length > 0) {
          initialMap[migratedGrade] = v2Data.library;
        }

        setActivitiesByGrade(initialMap);
        setSelectedGrade(migratedGrade);
        if (Array.isArray(v2Data.sequence)) setSequence(v2Data.sequence);
        if (typeof v2Data.title === 'string') setTitle(v2Data.title);
        if (v2Data.themeId) {
          const found = THEMES.find(t => t.id === v2Data.themeId);
          if (found) setTheme(found);
        }
        setSessions([]);
      }
    } catch (e) {
      console.error('Failed to load or migrate visual agenda state:', e);
    }
  }, []);

  // Save to visual-agenda-v4 on state changes
  useEffect(() => {
    try {
      const v4Data: VisualAgendaV4Data = {
        schemaVersion: 4,
        selectedGrade,
        activitiesByGrade,
        sequence,
        title,
        themeId: theme.id,
        activityTypes,
        sessions,
        currentSessionId,
        plannedDate,
        ls,
        greeting
      };
      localStorage.setItem('visual-agenda-v4', JSON.stringify(v4Data));
    } catch (e) {
      console.error('Failed to save v4 state to localStorage:', e);
    }
  }, [
    selectedGrade, 
    activitiesByGrade, 
    sequence, 
    title, 
    theme, 
    activityTypes, 
    sessions, 
    currentSessionId, 
    plannedDate, 
    ls, 
    greeting
  ]);

  // Clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // DND Sensors
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const currentGradeActivities = activitiesByGrade[selectedGrade] || [];

  const handleDragEndLibrary = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const currentList = activitiesByGrade[selectedGrade] || [];
      const oldIndex = currentList.findIndex((i) => i.id === active.id);
      const newIndex = currentList.findIndex((i) => i.id === over.id);
      if (oldIndex !== -1 && newIndex !== -1) {
        const reordered = arrayMove(currentList, oldIndex, newIndex);
        setActivitiesByGrade(prev => ({
          ...prev,
          [selectedGrade]: reordered
        }));
      }
    }
  };

  const handleDragEndSequence = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      setSequence((items) => {
        const oldIndex = items.findIndex((i) => i.id === active.id);
        const newIndex = items.findIndex((i) => i.id === over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const addActivityToSequence = (activity: Activity) => {
    setSequence(prev => [...prev, { 
      ...activity, 
      id: `seq-${Date.now()}-${Math.random().toString(36).substring(2, 7)}` 
    }]);
    showToast(`"${activity.name}" añadida a la sesión`, 'success');
  };

  const addMultipleActivitiesToSequence = (activitiesToAdd: Activity[]) => {
    const newItems: Activity[] = activitiesToAdd.map(activity => ({
      ...activity,
      id: `seq-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
    }));
    setSequence(prev => [...prev, ...newItems]);
    showToast(
      activitiesToAdd.length === 1
        ? `1 actividad añadida a la sesión`
        : `¡${activitiesToAdd.length} actividades añadidas a la sesión! 🎉`,
      'success'
    );
  };

  const removeActivityFromSequence = (index: number) => {
    const itemToRemove = sequence[index];
    const newSeq = [...sequence];
    newSeq.splice(index, 1);
    setSequence(newSeq);
    if (itemToRemove) {
      showToast(`"${itemToRemove.name}" quitada de la sesión`, 'info');
    }
  };

  const saveActivity = (activity: Activity) => {
    const currentList = activitiesByGrade[selectedGrade] || [];
    let updatedList: Activity[];
    
    if (editingActivity) {
      updatedList = currentList.map(a => a.id === activity.id ? activity : a);
      showToast('Actividad actualizada con éxito', 'success');
    } else {
      updatedList = [...currentList, { ...activity, id: `act-${Date.now()}` }];
      showToast(`Nueva actividad añadida al banco de ${selectedGrade}`, 'success');
    }

    setActivitiesByGrade(prev => ({
      ...prev,
      [selectedGrade]: updatedList
    }));
    
    setIsActivityModalOpen(false);
    setEditingActivity(null);
  };

  const deleteFromLibrary = (id: string) => {
    const currentList = activitiesByGrade[selectedGrade] || [];
    setActivitiesByGrade(prev => ({
      ...prev,
      [selectedGrade]: currentList.filter(a => a.id !== id)
    }));
    setIsActivityModalOpen(false);
    setEditingActivity(null);
    showToast(`Actividad eliminada del banco de ${selectedGrade}`, 'info');
  };

  const handleSaveType = (newOrUpdatedType: ActivityType) => {
    setActivityTypes(prev => {
      const exists = prev.some(t => t.id === newOrUpdatedType.id);
      if (exists) {
        return prev.map(t => t.id === newOrUpdatedType.id ? newOrUpdatedType : t);
      }
      return [newOrUpdatedType, ...prev];
    });
    showToast('Tipo de actividad guardado correctamente', 'success');
  };

  const handleDeleteType = (id: string) => {
    setActivityTypes(prev => prev.filter(t => t.id !== id));
    showToast('Tipo de actividad personalizado eliminado', 'info');
  };

  // Session Management Handlers
  const handleSaveSession = () => {
    if (sequence.length === 0) {
      showToast("Añade al menos una actividad a Today's Sequence antes de guardar la sesión", 'error');
      return;
    }

    // Complete snapshot copy of the sequence activities
    const activitiesSnapshot: Activity[] = sequence.map(act => ({
      ...act,
      id: act.id || `seq-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
    }));

    const now = new Date().toISOString();
    const existingIndex = sessions.findIndex(s => s.id === currentSessionId);

    if (existingIndex !== -1 && currentSessionId) {
      // Update existing session
      const updatedSession: ClassSession = {
        ...sessions[existingIndex],
        plannedDate: plannedDate || getTodayDateString(),
        grade: selectedGrade,
        name: title || 'English Lesson',
        ls: ls || 'LS 1',
        greeting: greeting || 'GOOD MORNING CLASS!',
        activities: activitiesSnapshot,
        completedActivityIds: Array.from(completedIds),
        status: completedIds.size === sequence.length && sequence.length > 0 
          ? 'completed' 
          : completedIds.size > 0 
            ? 'in_progress' 
            : 'planned',
        updatedAt: now
      };

      setSessions(prev => {
        const copy = [...prev];
        copy[existingIndex] = updatedSession;
        return copy;
      });

      showToast(`Sesión actualizada (${formatSpanishDate(updatedSession.plannedDate)} · ${selectedGrade})`, 'success');
    } else {
      // Create new session
      const newSessionId = `session-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const newSession: ClassSession = {
        id: newSessionId,
        plannedDate: plannedDate || getTodayDateString(),
        grade: selectedGrade,
        name: title || 'English Lesson',
        ls: ls || 'LS 1',
        greeting: greeting || 'GOOD MORNING CLASS!',
        activities: activitiesSnapshot,
        completedActivityIds: Array.from(completedIds),
        status: completedIds.size === sequence.length && sequence.length > 0 
          ? 'completed' 
          : completedIds.size > 0 
            ? 'in_progress' 
            : 'planned',
        createdAt: now,
        updatedAt: now
      };

      setSessions(prev => [newSession, ...prev]);
      setCurrentSessionId(newSessionId);
      showToast(`Sesión guardada (${formatSpanishDate(newSession.plannedDate)} · ${selectedGrade}) 🎉`, 'success');
    }
  };

  const handleLoadSession = (session: ClassSession) => {
    setSelectedGrade(session.grade);
    setPlannedDate(session.plannedDate || getTodayDateString());
    setTitle(session.name || 'English Lesson');
    setLs(session.ls || 'LS 1');
    setGreeting(session.greeting || 'GOOD MORNING CLASS!');
    
    // Deep snapshot copy of activities
    const activitiesCopy = (session.activities || []).map(a => ({ ...a }));
    setSequence(activitiesCopy);
    
    // Progress restoration
    const completedSet = new Set(session.completedActivityIds || []);
    setCompletedIds(completedSet);
    setCurrentSessionId(session.id);
    
    showToast(`Sesión cargada: ${session.name} (${formatSpanishDate(session.plannedDate)})`, 'success');
  };

  const handleContinuePending = (session: ClassSession) => {
    const completedSet = new Set(session.completedActivityIds || []);
    const pendingActivities = (session.activities || []).filter(a => !completedSet.has(a.id));
    
    // Generate new instance IDs for the pending activities
    const newSeq: Activity[] = pendingActivities.map(a => ({
      ...a,
      id: `seq-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
    }));

    setSelectedGrade(session.grade);
    setPlannedDate(getTodayDateString()); // Fresh today date for continuation
    setTitle(`${session.name} (Continuación)`);
    setLs(session.ls || 'LS 1');
    setGreeting(session.greeting || 'GOOD MORNING CLASS!');
    setSequence(newSeq);
    setCompletedIds(new Set()); // Empty fresh progress
    setCurrentSessionId(null); // Fresh preparation ready to be saved as new session
    
    showToast(`Preparando continuación con ${newSeq.length} actividades pendientes`, 'info');
  };

  const handleDuplicateSession = (session: ClassSession) => {
    const newId = `session-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const duplicated: ClassSession = {
      ...session,
      id: newId,
      name: `${session.name} (Copia)`,
      plannedDate: getTodayDateString(),
      status: 'planned',
      completedActivityIds: [],
      activities: (session.activities || []).map(a => ({
        ...a,
        id: `seq-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
      })),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setSessions(prev => [duplicated, ...prev]);
    showToast(`Sesión duplicada: "${duplicated.name}"`, 'success');
  };

  const handleDeleteSession = (sessionId: string) => {
    const sessionToDelete = sessions.find(s => s.id === sessionId);
    if (!sessionToDelete) return;

    setSessions(prev => prev.filter(s => s.id !== sessionId));
    if (currentSessionId === sessionId) {
      setCurrentSessionId(null);
    }

    showToast(
      `Sesión "${sessionToDelete.name}" eliminada`,
      'info',
      'Deshacer',
      () => {
        setSessions(prev => [sessionToDelete, ...prev]);
        showToast('Sesión restaurada con éxito', 'success');
      }
    );
  };

  const handleNewSessionReset = () => {
    setCurrentSessionId(null);
    setPlannedDate(getTodayDateString());
    setSequence([]);
    setCompletedIds(new Set());
    setTitle('English Lesson Routine & Activities');
    setLs('LS 1');
    setGreeting('GOOD MORNING CLASS!');
    showToast('Nueva sesión en blanco iniciada', 'info');
  };

  const toggleCompleted = (id: string) => {
    const newCompleted = new Set(completedIds);
    if (newCompleted.has(id)) {
      newCompleted.delete(id);
    } else {
      newCompleted.add(id);
    }
    setCompletedIds(newCompleted);

    // Synchronize with session if currently loaded
    if (currentSessionId) {
      setSessions(prev => prev.map(s => {
        if (s.id === currentSessionId) {
          const allDone = newCompleted.size === sequence.length && sequence.length > 0;
          return {
            ...s,
            completedActivityIds: Array.from(newCompleted),
            status: allDone ? 'completed' : newCompleted.size > 0 ? 'in_progress' : s.status,
            updatedAt: new Date().toISOString()
          };
        }
        return s;
      }));
    }
  };

  const startClass = () => {
    if (sequence.length > 0) {
      setCurrentIndex(0);
      setView('class');

      // If we have a current session, ensure it's marked as in_progress
      if (currentSessionId) {
        setSessions(prev => prev.map(s => {
          if (s.id === currentSessionId) {
            return {
              ...s,
              status: s.status === 'completed' ? 'completed' : 'in_progress',
              updatedAt: new Date().toISOString()
            };
          }
          return s;
        }));
      }
    }
  };

  // Export JSON (v4 format)
  const handleExportJSON = () => {
    const v4Payload: VisualAgendaV4Data = {
      schemaVersion: 4,
      selectedGrade,
      activitiesByGrade,
      sequence,
      title,
      themeId: theme.id,
      activityTypes,
      sessions,
      currentSessionId,
      plannedDate,
      ls,
      greeting
    };
    const blob = new Blob([JSON.stringify(v4Payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const sanitizedGrade = selectedGrade.replace(/[\s.º]/g, '-');
    a.download = `agenda-visual-v4-${sanitizedGrade}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Copia de seguridad completa (v4) exportada con éxito', 'success');
  };

  // Import JSON (supports v4, v3 and legacy v2 auto-migration)
  const handleImportJSON = (file: File) => {
    const reader = new FileReader();
    reader.onload = (re) => {
      try {
        const rawContent = re.target?.result as string;
        const data = JSON.parse(rawContent);

        if (!data || typeof data !== 'object') {
          throw new Error('El archivo no contiene un JSON válido');
        }

        // Case 1: Schema v4 structure
        if (data.schemaVersion === 4 && data.activitiesByGrade) {
          const importedGrade = normalizeGrade(data.selectedGrade);
          const initialMap = createInitialActivitiesByGrade();

          GRADES.forEach(g => {
            if (Array.isArray(data.activitiesByGrade[g])) {
              initialMap[g] = data.activitiesByGrade[g];
            }
          });

          setActivitiesByGrade(initialMap);
          setSelectedGrade(importedGrade);
          if (Array.isArray(data.sequence)) setSequence(data.sequence);
          if (typeof data.title === 'string') setTitle(data.title);
          if (typeof data.plannedDate === 'string') setPlannedDate(data.plannedDate);
          if (typeof data.ls === 'string') setLs(data.ls);
          if (typeof data.greeting === 'string') setGreeting(data.greeting);
          if (Array.isArray(data.sessions)) setSessions(data.sessions);
          if (typeof data.currentSessionId === 'string') setCurrentSessionId(data.currentSessionId);
          if (data.themeId) {
            const found = THEMES.find(t => t.id === data.themeId);
            if (found) setTheme(found);
          }
          if (Array.isArray(data.activityTypes) && data.activityTypes.length > 0) {
            setActivityTypes(data.activityTypes);
          }

          showToast('¡Copia de seguridad (v4) cargada con éxito! 🎉', 'success');
          return;
        }

        // Case 2: Schema v3 structure
        if (data.schemaVersion === 3 && data.activitiesByGrade) {
          const importedGrade = normalizeGrade(data.selectedGrade);
          const initialMap = createInitialActivitiesByGrade();

          GRADES.forEach(g => {
            if (Array.isArray(data.activitiesByGrade[g])) {
              initialMap[g] = data.activitiesByGrade[g];
            }
          });

          setActivitiesByGrade(initialMap);
          setSelectedGrade(importedGrade);
          if (Array.isArray(data.sequence)) setSequence(data.sequence);
          if (typeof data.title === 'string') setTitle(data.title);
          if (data.themeId) {
            const found = THEMES.find(t => t.id === data.themeId);
            if (found) setTheme(found);
          }
          if (Array.isArray(data.activityTypes) && data.activityTypes.length > 0) {
            setActivityTypes(data.activityTypes);
          }

          showToast('¡Copia v3 migrada a v4 con éxito! 🎉', 'success');
          return;
        }

        // Case 3: Legacy v2 or v1 structure
        if (data.library || data.level || data.sequence) {
          const legacyGrade = normalizeGrade(data.level || data.selectedGrade);
          const initialMap = createInitialActivitiesByGrade();

          if (Array.isArray(data.library)) {
            initialMap[legacyGrade] = data.library;
          }

          setActivitiesByGrade(initialMap);
          setSelectedGrade(legacyGrade);
          if (Array.isArray(data.sequence)) setSequence(data.sequence);
          if (typeof data.title === 'string') setTitle(data.title);
          if (data.themeId) {
            const found = THEMES.find(t => t.id === data.themeId);
            if (found) setTheme(found);
          }

          showToast('¡Copia antigua migrada a v4 con éxito! 🎉', 'success');
          return;
        }

        throw new Error('Estructura de archivo no reconocida');
      } catch (err: any) {
        showToast(err?.message || 'Error al cargar el archivo de copia de seguridad.', 'error');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-blue-100">
      {/* Toast Notification Container */}
      <div className="fixed top-6 right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-4 sm:px-0">
        <AnimatePresence>
          {toasts.map(toast => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              className={cn(
                "pointer-events-auto flex items-center gap-3 p-4 rounded-2xl shadow-xl border backdrop-blur-md text-sm font-bold",
                toast.type === 'success' && "bg-emerald-500/95 border-emerald-400 text-white",
                toast.type === 'error' && "bg-rose-500/95 border-rose-400 text-white",
                toast.type === 'info' && "bg-slate-900/95 border-slate-700 text-white"
              )}
            >
              {toast.type === 'success' && <CheckCircle2 size={20} className="shrink-0 text-emerald-100" />}
              {toast.type === 'error' && <AlertCircle size={20} className="shrink-0 text-rose-100" />}
              {toast.type === 'info' && <Info size={20} className="shrink-0 text-blue-200" />}
              
              <span className="flex-1 min-w-0 break-words">{toast.message}</span>
              
              {toast.actionLabel && toast.onAction && (
                <button
                  type="button"
                  onClick={() => {
                    toast.onAction?.();
                    removeToast(toast.id);
                  }}
                  className="px-2.5 py-1 bg-white text-slate-900 hover:bg-slate-100 rounded-lg text-xs font-black transition-all shrink-0 shadow-xs active:scale-95"
                >
                  {toast.actionLabel}
                </button>
              )}

              <button 
                type="button"
                onClick={() => removeToast(toast.id)}
                className="p-1 hover:bg-white/20 rounded-lg transition-colors text-white/80 shrink-0"
              >
                <X size={16} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <AnimatePresence mode="wait">
        {view === 'setup' ? (
          <motion.div 
            key="setup"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8"
          >
            {/* Top Navigation Header */}
            <header className={cn("flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8 p-6 sm:p-8 rounded-3xl text-white shadow-xl transition-colors duration-500", theme.primary)}>
              <div>
                <div className="flex items-center gap-2 mb-1 opacity-90">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-widest bg-white/20 border border-white/30">
                    Primaria CEIP Antonio Gala
                  </span>
                  <span className="text-xs font-bold">• Agenda Visual</span>
                </div>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight">
                  Visual Agenda & Lesson Flow
                </h1>
              </div>

              <div className="flex flex-wrap items-center gap-2 sm:gap-3 w-full md:w-auto">
                {/* Main Sessions Access Button */}
                <button
                  type="button"
                  onClick={() => setIsSessionsModalOpen(true)}
                  title="Gestión y Planificación de Sesiones"
                  className="bg-white text-indigo-900 px-4 py-2.5 sm:px-4.5 sm:py-3 rounded-2xl font-black flex items-center gap-2 transition-all shadow-md active:scale-95 text-xs sm:text-sm hover:bg-white/90"
                >
                  <Calendar size={18} className="text-indigo-600" />
                  <span>Sesiones</span>
                  <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[11px] font-black">
                    {sessions.length}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsActivityTypesModalOpen(true)}
                  title="Gestor de Tipos de Actividad"
                  className="bg-white/20 hover:bg-white/30 px-3.5 py-2.5 sm:px-4 sm:py-3 rounded-2xl font-bold flex items-center gap-2 transition-all border border-white/30 text-white shadow-sm active:scale-95 text-xs sm:text-sm"
                >
                  <Sparkles size={17} />
                  <span>Tipos ({activityTypes.length})</span>
                </button>

                <a
                  href="/agenda-visual-completa.zip"
                  download="agenda-visual-completa.zip"
                  title="Descargar Código Fuente en ZIP"
                  className="bg-white/20 hover:bg-white/30 px-3.5 py-2.5 sm:px-4 sm:py-3 rounded-2xl font-bold flex items-center gap-2 transition-all border border-white/30 text-white shadow-sm active:scale-95 text-xs sm:text-sm"
                >
                  <FileArchive size={17} />
                  <span>ZIP</span>
                </a>

                <button 
                  type="button"
                  onClick={() => setIsThemeModalOpen(true)}
                  title="Cambiar Tema de Color"
                  className="bg-white/20 hover:bg-white/30 p-2.5 sm:p-3 rounded-2xl transition-all border border-white/30 active:scale-95"
                >
                  <Palette size={18} />
                </button>

                <button 
                  type="button"
                  onClick={handleExportJSON}
                  title="Exportar datos completos de la agenda (JSON v4)"
                  className="bg-white/20 hover:bg-white/30 p-2.5 sm:p-3 rounded-2xl transition-all border border-white/30 active:scale-95"
                >
                  <Download size={18} />
                </button>

                <button 
                  type="button"
                  onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = '.json';
                    input.onchange = (e) => {
                      const file = (e.target as HTMLInputElement).files?.[0];
                      if (file) handleImportJSON(file);
                    };
                    input.click();
                  }}
                  title="Cargar datos de la agenda (JSON v4, v3 o v2)"
                  className="bg-white/20 hover:bg-white/30 p-2.5 sm:p-3 rounded-2xl transition-all border border-white/30 active:scale-95"
                >
                  <Upload size={18} />
                </button>

                <button 
                  type="button"
                  onClick={() => { setEditingActivity(null); setIsActivityModalOpen(true); }}
                  className="bg-white/20 hover:bg-white/30 text-white px-3.5 py-2.5 sm:px-4 sm:py-3 rounded-2xl font-bold flex items-center gap-1.5 transition-all border border-white/30 shadow-xs active:scale-95 text-xs sm:text-sm ml-auto md:ml-0"
                >
                  <Plus size={18} /> <span>Nueva Actividad</span>
                </button>
              </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Session Configuration & Library */}
              <div className="lg:col-span-7 space-y-6">
                {/* 1. DATOS DE LA CLASE: Curso, Fecha, Título, LS, Saludo */}
                <SessionConfigCard
                  selectedGrade={selectedGrade}
                  onSelectGrade={setSelectedGrade}
                  plannedDate={plannedDate}
                  onChangePlannedDate={setPlannedDate}
                  title={title}
                  onChangeTitle={setTitle}
                  ls={ls}
                  onChangeLS={setLs}
                  greeting={greeting}
                  onChangeGreeting={setGreeting}
                  currentSessionId={currentSessionId}
                  onNewSession={handleNewSessionReset}
                  totalGradeActivities={currentGradeActivities.length}
                  theme={theme}
                />

                {/* 2. ACTIVIDADES: Library specific to selected Grade */}
                <section className="bg-white p-6 sm:p-7 rounded-[2rem] shadow-xs border border-slate-100">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                        <h2 className="text-xs font-black uppercase tracking-wider text-slate-400">
                          Banco de Actividades — {selectedGrade}
                        </h2>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Toca una tarjeta para enviarla a la secuencia · Arrastra para ordenar el banco
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => { setEditingActivity(null); setIsActivityModalOpen(true); }}
                      className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1.5 bg-indigo-50 hover:bg-indigo-100 px-3.5 py-2 rounded-xl border border-indigo-200 transition-all self-start sm:self-auto"
                    >
                      <Plus size={15} /> Añadir a {selectedGrade}
                    </button>
                  </div>
                  
                  {currentGradeActivities.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-16 text-slate-300 border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50">
                      <LayoutGrid size={48} className="mb-3 opacity-30 text-slate-400" />
                      <p className="font-bold text-sm text-slate-500">No hay actividades guardadas en {selectedGrade}</p>
                      <p className="text-xs text-slate-400 mt-1 max-w-xs text-center">
                        Crea actividades personalizadas o selecciona tipos predefinidos.
                      </p>
                      <button
                        type="button"
                        onClick={() => { setEditingActivity(null); setIsActivityModalOpen(true); }}
                        className="mt-4 px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-black shadow-md hover:bg-indigo-700 transition-all"
                      >
                        Crear primera actividad
                      </button>
                    </div>
                  ) : (
                    <DndContext 
                      sensors={sensors}
                      collisionDetection={closestCenter}
                      onDragEnd={handleDragEndLibrary}
                    >
                      <SortableContext 
                        items={currentGradeActivities.map(a => a.id)}
                        strategy={rectSortingStrategy}
                      >
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
                          {currentGradeActivities.map(activity => (
                            <SortableActivityCard 
                              key={activity.id} 
                              activity={activity}
                              activityTypes={activityTypes}
                              onAdd={addActivityToSequence}
                              onEdit={(a) => { setEditingActivity(a); setIsActivityModalOpen(true); }}
                            />
                          ))}
                        </div>
                      </SortableContext>
                    </DndContext>
                  )}
                </section>
              </div>

              {/* Right Column: 3. TODAY'S SEQUENCE */}
              <div className="lg:col-span-5 flex flex-col gap-6">
                <section className="bg-white p-6 sm:p-7 rounded-[2rem] shadow-xs border border-slate-100 flex-1 min-h-[480px] flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-xs font-black uppercase tracking-wider text-slate-400">
                        Today's Sequence ({sequence.length})
                      </h2>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Secuencia ordenada para la clase de {formatSpanishDate(plannedDate)}
                      </p>
                    </div>
                    {sequence.length > 0 && (
                      <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200">
                        Lista para proyectar
                      </span>
                    )}
                  </div>

                  {/* Prominent Session Preparation Button */}
                  <button
                    type="button"
                    onClick={() => setIsSessionPickerOpen(true)}
                    className={cn(
                      "w-full py-4 px-5 rounded-2xl font-black text-sm sm:text-base transition-all flex items-center justify-center gap-2.5 shadow-md active:scale-98 border-2 mb-5",
                      theme.primary,
                      "text-white hover:opacity-95 shadow-blue-100"
                    )}
                  >
                    <Plus size={20} strokeWidth={3} />
                    <span>＋ Añadir actividades a la sesión</span>
                  </button>
                  
                  <div className="flex-1">
                    {sequence.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center py-12 px-4 text-slate-300 border-2 border-dashed border-slate-100 rounded-3xl bg-slate-50/50">
                        <Layers size={44} className="mb-3 opacity-30 text-slate-400" />
                        <p className="font-bold text-slate-600 text-sm">Secuencia vacía</p>
                        <p className="text-xs text-slate-400 mt-1 text-center max-w-[240px]">
                          Pulsa el botón superior para seleccionar actividades del banco de {selectedGrade}.
                        </p>
                        <button
                          type="button"
                          onClick={() => setIsSessionPickerOpen(true)}
                          className="mt-4 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center gap-1.5 active:scale-95"
                        >
                          <Plus size={15} strokeWidth={3} />
                          <span>Elegir actividades de {selectedGrade}</span>
                        </button>
                      </div>
                    ) : (
                      <DndContext 
                        sensors={sensors}
                        collisionDetection={closestCenter}
                        onDragEnd={handleDragEndSequence}
                      >
                        <SortableContext 
                          items={sequence.map(s => s.id)}
                          strategy={verticalListSortingStrategy}
                        >
                          <div className="space-y-2.5">
                            {sequence.map((item, idx) => (
                              <SortableSequenceItem 
                                key={item.id} 
                                activity={item} 
                                index={idx} 
                                onRemove={removeActivityFromSequence} 
                              />
                            ))}
                          </div>
                        </SortableContext>
                      </DndContext>
                    )}
                  </div>

                  {/* Actions under Sequence */}
                  <div className="pt-6 mt-6 border-t border-slate-100 space-y-3">
                    {/* Guardar Sesión Action */}
                    <button
                      type="button"
                      onClick={handleSaveSession}
                      disabled={sequence.length === 0}
                      className={cn(
                        "w-full py-3.5 px-5 rounded-2xl font-black text-sm sm:text-base transition-all flex items-center justify-center gap-2.5 border-2 shadow-sm active:scale-95",
                        sequence.length > 0
                          ? "bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border-indigo-200"
                          : "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
                      )}
                    >
                      <Save size={18} strokeWidth={2.5} />
                      <span>{currentSessionId ? 'Actualizar sesión guardada' : 'Guardar sesión'}</span>
                    </button>

                    {/* Start Class Projection */}
                    <button 
                      type="button"
                      onClick={startClass}
                      disabled={sequence.length === 0}
                      className={cn(
                        "w-full py-4 sm:py-5 rounded-2xl font-black text-lg sm:text-xl shadow-lg transition-all flex items-center justify-center gap-3 active:scale-95 text-white",
                        sequence.length > 0 ? `${theme.primary} hover:opacity-95 shadow-blue-200` : "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none"
                      )}
                    >
                      <Play size={22} className="fill-current" />
                      <span>Start Class! (PDI / TV)</span>
                    </button>

                    {sequence.length > 0 && (
                      <button 
                        type="button"
                        onClick={() => {
                          setSequence([]);
                          setCompletedIds(new Set());
                          showToast('Secuencia vaciada', 'info');
                        }}
                        className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-500 py-3 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2"
                      >
                        <RotateCcw size={15} /> Vaciar secuencia de hoy
                      </button>
                    )}
                  </div>
                </section>
              </div>
            </div>
          </motion.div>
        ) : (
          /* ========================================================================= */
          /* CLASSROOM / PDI / SMART TV PRESENTATION VIEW                              */
          /* ========================================================================= */
          <motion.div 
            key="class"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={cn(
              "min-h-screen flex flex-col justify-between transition-colors duration-700",
              currentIndex < sequence.length 
                ? sequence[currentIndex].color.split(' ')[0].replace('-100', '-50')
                : "bg-emerald-50"
            )}
          >
            {/* Class Presentation Header with Date, Grade, LS, Greeting */}
            <header className="p-6 sm:p-8 flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-white/80 backdrop-blur-md shadow-xs text-slate-700 border border-slate-200">
                    CEIP ANTONIO GALA · {selectedGrade}
                  </span>
                  {ls && (
                    <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-indigo-50/90 backdrop-blur-md shadow-xs text-indigo-700 border border-indigo-200">
                      {ls}
                    </span>
                  )}
                  <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-white/80 backdrop-blur-md shadow-xs text-slate-600 border border-slate-200">
                    {formatSpanishDate(plannedDate)}
                  </span>
                  {greeting && (
                    <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-900 border border-amber-200">
                      {greeting}
                    </span>
                  )}
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-800 tracking-tight">
                  {title}
                </h2>
              </div>
              <div className="flex items-center gap-3 sm:gap-4">
                <div className="bg-white/80 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-slate-200 shadow-xs text-xl sm:text-2xl font-black text-slate-800 flex items-center gap-2.5">
                  <Clock size={22} className="text-slate-500" />
                  {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
                <button 
                  type="button"
                  onClick={() => setView('setup')}
                  className="bg-white p-3.5 rounded-2xl shadow-sm border border-slate-200 hover:bg-slate-100 transition-all text-slate-600 hover:text-slate-900 active:scale-95"
                  title="Volver a la configuración de la sesión"
                >
                  <Edit2 size={22} />
                </button>
              </div>
            </header>

            {/* Main Center Stage */}
            <main className="flex-1 flex flex-col items-center justify-center p-6 gap-8 sm:gap-10">
              <AnimatePresence mode="wait">
                {currentIndex < sequence.length ? (
                  <motion.div
                    key={sequence[currentIndex].id}
                    initial={{ opacity: 0, scale: 0.85, y: 15 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 1.15, y: -15 }}
                    transition={{ type: 'spring', damping: 22, stiffness: 200 }}
                    className="w-full max-w-3xl bg-white rounded-[3.5rem] shadow-2xl border-8 border-white flex flex-col items-center justify-center p-8 sm:p-14 relative overflow-hidden text-center"
                  >
                    {/* Decorative backdrop glow */}
                    <div className={cn("absolute inset-0 opacity-10 pointer-events-none", sequence[currentIndex].color.split(' ')[0])} />
                    
                    {/* Activity Type badge if available */}
                    {sequence[currentIndex].typeId && (
                      <div className="mb-4">
                        <span className="px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest bg-slate-100 text-slate-600 border border-slate-200">
                          {activityTypes.find(t => t.id === sequence[currentIndex].typeId)?.name || 'Activity'}
                        </span>
                      </div>
                    )}

                    {/* Huge, Chunky Rounded Icon Badge for PDI distance viewing */}
                    <div className="mb-6">
                      <ActivityIconBadge 
                        icon={sequence[currentIndex].icon}
                        customImage={sequence[currentIndex].customImage}
                        colorClass={sequence[currentIndex].color}
                        size="hero"
                        className="shadow-2xl"
                      />
                    </div>
                    
                    {/* Activity Name (Huge bold for back row visibility) */}
                    <h3 className="text-4xl sm:text-6xl lg:text-7xl font-black text-slate-900 leading-tight mb-2 tracking-tight">
                      {sequence[currentIndex].name}
                    </h3>

                    {/* Optional Activity Description / Subtitle */}
                    {sequence[currentIndex].description && (
                      <p className="text-lg sm:text-2xl font-bold text-slate-500 max-w-xl mb-4">
                        {sequence[currentIndex].description}
                      </p>
                    )}
                    
                    {/* Step counter pill */}
                    <div className="mt-2 bg-slate-100 px-6 py-2 rounded-full font-black text-xs sm:text-sm text-slate-500 tracking-widest border border-slate-200">
                      STEP {currentIndex + 1} OF {sequence.length}
                    </div>

                    {/* Done Toggle Button */}
                    <button 
                      type="button"
                      onClick={() => toggleCompleted(sequence[currentIndex].id)}
                      className={cn(
                        "mt-6 flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-base sm:text-lg transition-all shadow-md active:scale-95",
                        completedIds.has(sequence[currentIndex].id) 
                          ? "bg-emerald-500 text-white shadow-emerald-200" 
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200 border border-slate-200"
                      )}
                    >
                      {completedIds.has(sequence[currentIndex].id) ? (
                        <>
                          <CheckCircle2 size={24} />
                          <span>Completed! 🎉</span>
                        </>
                      ) : (
                        <>
                          <Circle size={24} />
                          <span>Mark as Done</span>
                        </>
                      )}
                    </button>
                  </motion.div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.85 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="w-full max-w-3xl bg-white rounded-[3.5rem] shadow-2xl border-8 border-white flex flex-col items-center justify-center p-12 sm:p-16 text-center"
                  >
                    <motion.div
                      animate={{ rotate: [0, 12, -12, 0], scale: [1, 1.15, 1] }}
                      transition={{ repeat: Infinity, duration: 2.5 }}
                    >
                      <PartyPopper size={110} className="text-emerald-500 mb-6" />
                    </motion.div>
                    <h3 className="text-5xl sm:text-6xl font-black text-emerald-600 mb-3">
                      Class Finished!
                    </h3>
                    <p className="text-xl sm:text-2xl font-bold text-slate-500 mb-8">
                      Great job today, everyone! ⭐
                    </p>
                    <button
                      type="button"
                      onClick={() => setView('setup')}
                      className="px-8 py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-lg shadow-lg active:scale-95 transition-all"
                    >
                      Volver a la Agenda
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Visual Timeline / Step Navigator */}
              <div className="flex gap-3 sm:gap-4 items-center flex-wrap justify-center max-w-5xl px-4">
                {sequence.map((item, idx) => {
                  const isCurrent = idx === currentIndex;
                  const isDone = completedIds.has(item.id);
                  return (
                    <button 
                      key={item.id} 
                      type="button"
                      onClick={() => setCurrentIndex(idx)}
                      className={cn(
                        "relative transition-transform active:scale-95 group rounded-2xl",
                        isCurrent ? "scale-115 z-10" : "scale-100 opacity-70 hover:opacity-100"
                      )}
                      title={`${idx + 1}. ${item.name}`}
                    >
                      <div className="relative">
                        <ActivityIconBadge 
                          icon={item.icon}
                          customImage={item.customImage}
                          colorClass={item.color}
                          size="md"
                          className={cn(
                            isCurrent && "ring-4 ring-blue-500 shadow-xl",
                            isDone && "border-emerald-500"
                          )}
                        />
                        {isDone && (
                          <div className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-md border-2 border-white">
                            <Check size={14} strokeWidth={3} />
                          </div>
                        )}
                      </div>

                      {isCurrent && (
                        <motion.div 
                          layoutId="active-timeline-indicator"
                          className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-blue-600 rounded-full"
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </main>

            {/* Presentation Navigation Footer */}
            <footer className="p-6 sm:p-8 space-y-6">
              {/* Progress Bar */}
              <div className="w-full max-w-4xl mx-auto h-3.5 bg-slate-200/80 rounded-full overflow-hidden shadow-inner">
                <motion.div 
                  className="h-full bg-gradient-to-r from-emerald-400 to-blue-500"
                  initial={{ width: 0 }}
                  animate={{ 
                    width: sequence.length > 0 
                      ? `${(completedIds.size / sequence.length) * 100}%` 
                      : '0%' 
                  }}
                  transition={{ duration: 0.4 }}
                />
              </div>

              <div className="flex justify-center items-center gap-4 sm:gap-6">
                <button 
                  type="button"
                  onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
                  disabled={currentIndex === 0}
                  className="px-8 sm:px-12 py-4 sm:py-5 bg-white border-2 border-slate-200 rounded-3xl font-black text-lg sm:text-xl text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:pointer-events-none transition-all flex items-center gap-2 shadow-sm active:scale-95"
                >
                  <ChevronLeft size={26} strokeWidth={3} /> Anterior
                </button>
                
                <button 
                  type="button"
                  onClick={() => setCurrentIndex(Math.min(sequence.length, currentIndex + 1))}
                  disabled={currentIndex > sequence.length - 1}
                  className={cn(
                    "px-10 sm:px-16 py-4 sm:py-5 rounded-3xl font-black text-lg sm:text-xl text-white shadow-xl transition-all flex items-center gap-2 active:scale-95",
                    currentIndex < sequence.length 
                      ? "bg-emerald-500 hover:bg-emerald-600 shadow-emerald-200" 
                      : "bg-slate-300 cursor-not-allowed shadow-none"
                  )}
                >
                  <span>Siguiente</span>
                  <ChevronRight size={26} strokeWidth={3} />
                </button>
              </div>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Activity Create / Edit Modal with Type Selector */}
      <ActivityModal 
        isOpen={isActivityModalOpen} 
        onClose={() => { setIsActivityModalOpen(false); setEditingActivity(null); }}
        onSave={saveActivity}
        onDelete={deleteFromLibrary}
        initialActivity={editingActivity}
        activityTypes={activityTypes}
        currentGradeName={selectedGrade}
      />

      {/* Activity Types Manager Modal */}
      <ActivityTypesModal
        isOpen={isActivityTypesModalOpen}
        onClose={() => setIsActivityTypesModalOpen(false)}
        activityTypes={activityTypes}
        onSaveType={handleSaveType}
        onDeleteType={handleDeleteType}
      />

      {/* Theme Modal */}
      <ThemeModal 
        isOpen={isThemeModalOpen} 
        onClose={() => setIsThemeModalOpen(false)}
        currentTheme={theme}
        onSelect={setTheme}
      />

      {/* Dedicated Session Activity Picker Modal */}
      <SessionActivityPickerModal
        isOpen={isSessionPickerOpen}
        onClose={() => setIsSessionPickerOpen(false)}
        gradeActivities={currentGradeActivities}
        activityTypes={activityTypes}
        currentGradeName={selectedGrade}
        currentSequence={sequence}
        onAddActivities={addMultipleActivitiesToSequence}
        onCreateNewActivity={() => {
          setEditingActivity(null);
          setIsActivityModalOpen(true);
        }}
      />

      {/* Sessions Management Modal */}
      <SessionsModal
        isOpen={isSessionsModalOpen}
        onClose={() => setIsSessionsModalOpen(false)}
        sessions={sessions}
        currentGrade={selectedGrade}
        onLoadSession={handleLoadSession}
        onContinuePending={handleContinuePending}
        onDuplicateSession={handleDuplicateSession}
        onDeleteSession={handleDeleteSession}
      />
    </div>
  );
}

import { Activity, ActivityType } from '../types';
import { ActivityIconBadge } from './IconRenderer';
import { GripVertical, Edit2, Plus, Info } from 'lucide-react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { cn } from '../lib/utils';

interface ActivityCardProps {
  key?: string | number;
  activity: Activity;
  activityTypes?: ActivityType[];
  onAdd?: (activity: Activity) => void;
  onEdit?: (activity: Activity) => void;
}

export function SortableActivityCard({
  activity,
  activityTypes = [],
  onAdd,
  onEdit
}: ActivityCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: activity.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 50 : 1,
    opacity: isDragging ? 0.6 : 1,
  };

  const matchedType = activity.typeId 
    ? activityTypes.find(t => t.id === activity.typeId)
    : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "group relative bg-white p-3.5 sm:p-4 rounded-2xl sm:rounded-3xl border-2 transition-all flex flex-col items-center text-center select-none shadow-xs hover:shadow-md hover:border-blue-200",
        isDragging ? "shadow-2xl border-blue-400 rotate-2 scale-105" : "border-slate-100/90"
      )}
    >
      {/* Drag Handle */}
      <div 
        {...attributes} 
        {...listeners}
        className="absolute top-2.5 left-2.5 opacity-30 group-hover:opacity-100 cursor-grab active:cursor-grabbing p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-all touch-none"
        title="Arrastrar para reordenar"
      >
        <GripVertical size={16} />
      </div>

      {/* Edit Button */}
      {onEdit && (
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onEdit(activity);
          }}
          className="absolute top-2.5 right-2.5 opacity-0 group-hover:opacity-100 p-1.5 hover:bg-blue-50 rounded-lg text-slate-400 hover:text-blue-600 transition-all shadow-xs"
          title="Editar actividad"
        >
          <Edit2 size={16} />
        </button>
      )}

      {/* Card Content / Click to Add */}
      <div 
        onClick={() => onAdd?.(activity)}
        className="flex flex-col items-center w-full cursor-pointer pt-3 sm:pt-2"
      >
        {/* Prominent, chunky rounded icon badge */}
        <div className="relative my-1">
          <ActivityIconBadge 
            icon={activity.icon}
            customImage={activity.customImage}
            colorClass={activity.color}
            size="md"
            className="group-hover:scale-105 group-active:scale-95 transition-transform"
          />
        </div>

        {/* Activity Name */}
        <h4 className="font-black text-xs sm:text-sm text-slate-800 line-clamp-2 leading-snug mt-2 w-full px-1">
          {activity.name}
        </h4>

        {/* Optional Description / Subtitle */}
        {activity.description && (
          <p className="text-[11px] font-medium text-slate-400 line-clamp-1 mt-1 px-1">
            {activity.description}
          </p>
        )}

        {/* Tap to add indicator */}
        <div className="mt-2.5 w-full pt-2 border-t border-slate-100/80 flex items-center justify-center gap-1 text-[11px] font-bold text-slate-400 group-hover:text-blue-600 transition-colors">
          <Plus size={13} className="shrink-0" />
          <span>Añadir</span>
        </div>
      </div>
    </div>
  );
}

import React from 'react';

export interface PictogramProps {
  className?: string;
  size?: number | string;
}

const defaultProps = {
  width: 64,
  height: 64,
  viewBox: "0 0 64 64",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg",
};

export const Pictograms: Record<string, React.FC<PictogramProps>> = {
  // 1. ROUTINES & CLASSROOM
  Sun: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M32 6V12M32 52V58M6 32H12M52 32H58M13.6 13.6L17.8 17.8M46.2 46.2L50.4 50.4M13.6 50.4L17.8 46.2M46.2 17.8L50.4 13.6" 
        stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <circle cx="32" cy="32" r="16" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" />
      <circle cx="26" cy="30" r="2.5" fill="#1e293b" />
      <circle cx="38" cy="30" r="2.5" fill="#1e293b" />
      <path d="M26 36C27.8 39.5 36.2 39.5 38 36" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="22" cy="34" r="2" fill="#f43f5e" opacity="0.6" />
      <circle cx="42" cy="34" r="2" fill="#f43f5e" opacity="0.6" />
    </svg>
  ),

  Clock: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M12 18L20 12M52 18L44 12" stroke="#1e293b" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="15" cy="14" r="4" fill="#f43f5e" stroke="#1e293b" strokeWidth="2.5" />
      <circle cx="49" cy="14" r="4" fill="#f43f5e" stroke="#1e293b" strokeWidth="2.5" />
      <circle cx="32" cy="36" r="20" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <circle cx="32" cy="36" r="15" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <path d="M32 25V36L40 40" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="32" cy="36" r="2.5" fill="#f43f5e" />
      <path d="M20 54L16 60M44 54L48 60" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
    </svg>
  ),

  Explanation: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M20 56L24 44M44 56L40 44M32 44V58" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <rect x="8" y="10" width="48" height="34" rx="4" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <rect x="12" y="14" width="40" height="26" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <path d="M18 24L26 30L34 22L44 32" stroke="#f43f5e" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="18" cy="24" r="2.5" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="26" cy="30" r="2.5" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="34" cy="22" r="2.5" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="44" cy="32" r="2.5" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
    </svg>
  ),

  Instructions: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="12" y="12" width="40" height="46" rx="4" fill="#fed7aa" stroke="#1e293b" strokeWidth="3" />
      <rect x="22" y="6" width="20" height="10" rx="3" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <circle cx="32" cy="11" r="2" fill="#ffffff" />
      <rect x="18" y="22" width="6" height="6" rx="1.5" fill="#34d399" stroke="#1e293b" strokeWidth="2" />
      <path d="M28 25H44" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <rect x="18" y="33" width="6" height="6" rx="1.5" fill="#38bdf8" stroke="#1e293b" strokeWidth="2" />
      <path d="M28 36H44" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <rect x="18" y="44" width="6" height="6" rx="1.5" fill="#fbbf24" stroke="#1e293b" strokeWidth="2" />
      <path d="M28 47H38" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
    </svg>
  ),

  // 2. SPEAKING & ORAL
  Mic: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="24" y="8" width="16" height="28" rx="8" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <line x1="24" y1="20" x2="40" y2="20" stroke="#1e293b" strokeWidth="2" />
      <line x1="24" y1="26" x2="40" y2="26" stroke="#1e293b" strokeWidth="2" />
      <path d="M16 24C16 33 23 39 32 39C41 39 48 33 48 24" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <path d="M32 39V52M20 56H44" stroke="#1e293b" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M10 20C8 24 8 28 10 32M54 20C56 24 56 28 54 32" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" />
    </svg>
  ),

  OralQuestion: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M10 28C10 16.95 19.85 8 32 8C44.15 8 54 16.95 54 28C54 39.05 44.15 48 32 48C28 48 24.5 47 21 45.2L10 52L13 41.5C11.1 37.7 10 33 10 28Z" 
        fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M26 22C26 18.5 28.5 16 32 16C35.5 16 38 18.5 38 21.5C38 25 34.5 27 32 29.5V34" 
        stroke="#1e293b" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="32" cy="40" r="2.5" fill="#1e293b" />
    </svg>
  ),

  Speaking: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M12 52C12 43 18 36 26 36C33 36 38 31 38 24C38 15 32 10 22 10C14 10 10 16 10 22" 
        stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <circle cx="22" cy="22" r="12" fill="#fed7aa" stroke="#1e293b" strokeWidth="3" />
      <path d="M40 18C44 20 46 24 46 28C46 32 44 36 40 38" stroke="#34d399" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M48 12C54 16 57 22 57 28C57 34 54 40 48 44" stroke="#38bdf8" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  ),

  PairSpeaking: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M8 22C8 14 15 8 24 8C33 8 40 14 40 22C40 30 33 36 24 36C21 36 18.5 35.2 16 34L8 38L10 30.5C8.8 28 8 25 8 22Z" 
        fill="#2dd4bf" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <circle cx="18" cy="22" r="2" fill="#1e293b" />
      <circle cx="24" cy="22" r="2" fill="#1e293b" />
      <circle cx="30" cy="22" r="2" fill="#1e293b" />
      <path d="M30 38C30 32 36 27 43 27C50 27 56 32 56 38C56 44 50 49 43 49C40.5 49 38.5 48.3 36.5 47.3L30 51L31.5 44.8C30.5 42.8 30 40.5 30 38Z" 
        fill="#f43f5e" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <circle cx="38" cy="38" r="1.8" fill="#ffffff" />
      <circle cx="43" cy="38" r="1.8" fill="#ffffff" />
      <circle cx="48" cy="38" r="1.8" fill="#ffffff" />
    </svg>
  ),

  GroupSpeaking: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <circle cx="18" cy="34" r="8" fill="#38bdf8" stroke="#1e293b" strokeWidth="2.5" />
      <path d="M8 54C8 46 12 43 18 43C24 43 28 46 28 54" fill="#38bdf8" stroke="#1e293b" strokeWidth="2.5" />
      <circle cx="46" cy="34" r="8" fill="#fbbf24" stroke="#1e293b" strokeWidth="2.5" />
      <path d="M36 54C36 46 40 43 46 43C52 43 56 46 56 54" fill="#fbbf24" stroke="#1e293b" strokeWidth="2.5" />
      <circle cx="32" cy="28" r="9" fill="#c084fc" stroke="#1e293b" strokeWidth="3" />
      <path d="M20 54C20 44 25 41 32 41C39 41 44 44 44 54" fill="#c084fc" stroke="#1e293b" strokeWidth="3" />
      <path d="M24 10C24 6 27.5 4 32 4C36.5 4 40 6 40 10C40 14 36.5 16 32 16L28 18L29 15C26 14 24 12 24 10Z" 
        fill="#34d399" stroke="#1e293b" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  ),

  Presentation: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="6" y="8" width="52" height="32" rx="4" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <rect x="10" y="12" width="44" height="24" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <path d="M16 28L24 20L32 25L42 16" stroke="#f43f5e" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M26 40H38V56H26V40Z" fill="#fed7aa" stroke="#1e293b" strokeWidth="2.5" />
      <circle cx="32" cy="46" r="3" fill="#34d399" stroke="#1e293b" strokeWidth="1.5" />
      <path d="M20 56H44" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
    </svg>
  ),

  Megaphone: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M10 24V40L18 36L44 48V16L18 28L10 24Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <ellipse cx="44" cy="32" rx="4" ry="16" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <path d="M22 36V48C22 51 26 51 26 48V34" fill="#38bdf8" stroke="#1e293b" strokeWidth="2.5" />
      <path d="M52 24C56 28 56 36 52 40M57 18C62 26 62 38 57 46" stroke="#34d399" strokeWidth="3" strokeLinecap="round" />
    </svg>
  ),

  // 3. READING & VOCABULARY
  Reading: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M32 46C24 40 14 42 6 46V18C14 14 24 16 32 22C40 16 50 14 58 18V46C50 42 40 40 32 46Z" 
        fill="#38bdf8" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M32 46V22" stroke="#1e293b" strokeWidth="3" />
      <path d="M12 24C18 22 24 23 28 26M12 32C18 30 24 31 28 34M36 26C40 23 46 22 52 24M36 34C40 31 46 30 52 32" 
        stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M32 14V30L36 26L40 30V14" fill="#f43f5e" stroke="#1e293b" strokeWidth="2" />
    </svg>
  ),

  VocabPres: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="8" y="14" width="40" height="42" rx="4" fill="#c084fc" stroke="#1e293b" strokeWidth="3" />
      <rect x="12" y="18" width="32" height="24" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="28" cy="30" r="7" fill="#f43f5e" />
      <path d="M28 23C28 21 30 19 32 19" stroke="#34d399" strokeWidth="2" strokeLinecap="round" />
      <line x1="16" y1="48" x2="36" y2="48" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" />
      <path d="M36 50L56 22" stroke="#1e293b" strokeWidth="4" strokeLinecap="round" />
      <path d="M52 26L56 22L54 28" fill="#fbbf24" stroke="#1e293b" strokeWidth="2" />
      <path d="M50 8L52 14L58 16L52 18L50 24L48 18L42 16L48 14L50 8Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="2" />
    </svg>
  ),

  StructuresPres: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="8" y="16" width="22" height="20" rx="3" fill="#2dd4bf" stroke="#1e293b" strokeWidth="3" />
      <text x="14" y="30" fill="#1e293b" fontWeight="900" fontSize="11" fontFamily="sans-serif">He</text>
      <path d="M31 26H35M33 24V28" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <rect x="36" y="16" width="22" height="20" rx="3" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" />
      <text x="40" y="30" fill="#1e293b" fontWeight="900" fontSize="11" fontFamily="sans-serif">likes</text>
      <rect x="18" y="38" width="30" height="18" rx="3" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <text x="24" y="51" fill="#ffffff" fontWeight="900" fontSize="11" fontFamily="sans-serif">apples.</text>
    </svg>
  ),

  Flashcards: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="18" y="6" width="38" height="46" rx="4" transform="rotate(10 37 29)" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" />
      <rect x="10" y="14" width="38" height="46" rx="4" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <rect x="14" y="18" width="30" height="26" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <path d="M29 23L31 27L36 28L32 32L33 37L29 34L25 37L26 32L22 28L27 27L29 23Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="18" y1="50" x2="40" y2="50" stroke="#ffffff" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  ),

  // 4. WRITING & NOTEBOOK
  Worksheet: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M12 10C12 7.79 13.79 6 16 6H40L52 18V54C52 56.21 50.21 58 48 58H16C13.79 58 12 56.21 12 54V10Z" 
        fill="#ffffff" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M40 6V18H52" fill="#fed7aa" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <rect x="18" y="16" width="18" height="5" rx="1.5" fill="#38bdf8" stroke="#1e293b" strokeWidth="1.5" />
      <rect x="18" y="27" width="5" height="5" rx="1" fill="#34d399" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="27" y1="29.5" x2="44" y2="29.5" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      <rect x="18" y="37" width="5" height="5" rx="1" fill="#38bdf8" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="27" y1="39.5" x2="44" y2="39.5" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      <rect x="18" y="47" width="5" height="5" rx="1" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="27" y1="49.5" x2="40" y2="49.5" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  ),

  WorksheetCorrection: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="10" y="8" width="40" height="48" rx="4" fill="#ffffff" stroke="#1e293b" strokeWidth="3" />
      <line x1="18" y1="18" x2="38" y2="18" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="18" y1="28" x2="38" y2="28" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="18" y1="38" x2="38" y2="38" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="44" cy="42" r="14" fill="#34d399" stroke="#1e293b" strokeWidth="3" />
      <path d="M37 42L42 47L51 37" stroke="#ffffff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M32 8L44 20" stroke="#f43f5e" strokeWidth="4" strokeLinecap="round" />
    </svg>
  ),

  NotebookCopy: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="16" y="8" width="38" height="48" rx="4" fill="#818cf8" stroke="#1e293b" strokeWidth="3" />
      <circle cx="16" cy="16" r="3" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="16" cy="26" r="3" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="16" cy="36" r="3" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="16" cy="46" r="3" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <rect x="23" y="14" width="25" height="36" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <line x1="27" y1="22" x2="44" y2="22" stroke="#f43f5e" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="27" y1="28" x2="44" y2="28" stroke="#38bdf8" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="27" y1="34" x2="44" y2="34" stroke="#38bdf8" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="27" y1="40" x2="40" y2="40" stroke="#38bdf8" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M42 56L54 28L48 24L36 52L42 56Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="2" strokeLinejoin="round" />
      <path d="M54 28L58 22L52 18L48 24" fill="#f43f5e" stroke="#1e293b" strokeWidth="2" strokeLinejoin="round" />
      <path d="M36 52L33 60L42 56" fill="#fed7aa" stroke="#1e293b" strokeWidth="2" strokeLinejoin="round" />
      <polygon points="33,60 36,58 35,56" fill="#1e293b" />
    </svg>
  ),

  VocabCopy: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="12" y="8" width="40" height="48" rx="4" fill="#c084fc" stroke="#1e293b" strokeWidth="3" />
      <rect x="18" y="14" width="28" height="36" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <text x="22" y="27" fill="#f43f5e" fontWeight="900" fontSize="12" fontFamily="sans-serif">A</text>
      <text x="30" y="27" fill="#38bdf8" fontWeight="900" fontSize="12" fontFamily="sans-serif">B</text>
      <text x="38" y="27" fill="#34d399" fontWeight="900" fontSize="12" fontFamily="sans-serif">C</text>
      <line x1="22" y1="34" x2="42" y2="34" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
      <line x1="22" y1="41" x2="38" y2="41" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
      <path d="M42 52L56 22L50 18L38 48L42 52Z" fill="#34d399" stroke="#1e293b" strokeWidth="2" />
    </svg>
  ),

  StructuresCopy: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="10" y="8" width="44" height="48" rx="4" fill="#2dd4bf" stroke="#1e293b" strokeWidth="3" />
      <rect x="16" y="14" width="32" height="36" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <rect x="20" y="20" width="10" height="8" rx="1.5" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <rect x="32" y="20" width="12" height="8" rx="1.5" fill="#f43f5e" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="20" y1="34" x2="44" y2="34" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
      <line x1="20" y1="41" x2="40" y2="41" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),

  Pencil: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M18 52L50 20L44 14L12 46L18 52Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M50 20L56 14L50 8L44 14" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <line x1="48" y1="18" x2="46" y2="12" stroke="#1e293b" strokeWidth="2.5" />
      <path d="M12 46L6 58L18 52" fill="#fed7aa" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <polygon points="6,58 10,55 9,53" fill="#1e293b" />
    </svg>
  ),

  // 5. LISTENING & AUDIO
  Listening: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M14 36C14 22 22 12 32 12C42 12 50 22 50 36" stroke="#1e293b" strokeWidth="4" strokeLinecap="round" fill="none" />
      <rect x="8" y="32" width="12" height="20" rx="6" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <rect x="44" y="32" width="12" height="20" rx="6" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <path d="M26 38V46M32 34V50M38 38V46" stroke="#f43f5e" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  ),

  Song: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <circle cx="20" cy="46" r="8" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <circle cx="44" cy="38" r="8" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <path d="M28 46V18L52 10V38" stroke="#1e293b" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M28 18L52 10" stroke="#fbbf24" strokeWidth="5" strokeLinecap="round" />
      <circle cx="36" cy="28" r="2.5" fill="#fbbf24" />
      <circle cx="16" cy="18" r="2" fill="#34d399" />
    </svg>
  ),

  Radio: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="8" y="20" width="48" height="34" rx="6" fill="#818cf8" stroke="#1e293b" strokeWidth="3" />
      <path d="M16 20L36 8" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <circle cx="24" cy="37" r="10" fill="#ffffff" stroke="#1e293b" strokeWidth="2.5" />
      <circle cx="24" cy="37" r="4" fill="#f43f5e" />
      <rect x="40" y="28" width="10" height="5" rx="1.5" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <rect x="40" y="38" width="10" height="5" rx="1.5" fill="#34d399" stroke="#1e293b" strokeWidth="1.5" />
    </svg>
  ),

  // 6. DIGITAL & INTERACTIVE
  GeniallyVocab: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="8" y="8" width="48" height="36" rx="4" fill="#c084fc" stroke="#1e293b" strokeWidth="3" />
      <rect x="12" y="12" width="40" height="28" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="24" cy="24" r="6" fill="#fbbf24" stroke="#1e293b" strokeWidth="2" />
      <path d="M36 20L44 26L36 32Z" fill="#34d399" stroke="#1e293b" strokeWidth="2" strokeLinejoin="round" />
      <path d="M26 44H38V54H26V44Z" fill="#818cf8" stroke="#1e293b" strokeWidth="2.5" />
      <path d="M20 54H44" stroke="#1e293b" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  ),

  GeniallyStruct: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="14" y="10" width="36" height="28" rx="3" fill="#818cf8" stroke="#1e293b" strokeWidth="3" />
      <rect x="18" y="14" width="28" height="20" rx="1.5" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <rect x="22" y="18" width="8" height="5" rx="1" fill="#f43f5e" />
      <rect x="32" y="18" width="10" height="5" rx="1" fill="#38bdf8" />
      <rect x="22" y="25" width="20" height="5" rx="1" fill="#34d399" />
      <path d="M6 42H58L54 48H10L6 42Z" fill="#cbd5e1" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <line x1="28" y1="45" x2="36" y2="45" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),

  YouTubeVideo: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="6" y="12" width="52" height="38" rx="10" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <path d="M26 22L44 31L26 40V22Z" fill="#ffffff" stroke="#1e293b" strokeWidth="2.5" strokeLinejoin="round" />
      <circle cx="16" cy="18" r="2" fill="#ffffff" />
      <circle cx="48" cy="18" r="2" fill="#ffffff" />
    </svg>
  ),

  WordwallGame: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M12 24C12 18 18 14 32 14C46 14 52 18 52 24C52 38 46 50 38 50C34 50 32 44 32 44C32 44 30 50 26 50C18 50 12 38 12 24Z" 
        fill="#818cf8" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M22 24V32M18 28H26" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <circle cx="40" cy="24" r="3" fill="#f43f5e" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="44" cy="30" r="3" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="36" cy="30" r="3" fill="#34d399" stroke="#1e293b" strokeWidth="1.5" />
    </svg>
  ),

  GoogleForm: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="12" y="10" width="40" height="48" rx="4" fill="#a855f7" stroke="#1e293b" strokeWidth="3" />
      <rect x="16" y="16" width="32" height="38" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <rect x="24" y="6" width="16" height="8" rx="2" fill="#fed7aa" stroke="#1e293b" strokeWidth="2.5" />
      <circle cx="22" cy="24" r="3" fill="#a855f7" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="28" y1="24" x2="42" y2="24" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="22" cy="34" r="3" fill="#ffffff" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="28" y1="34" x2="42" y2="34" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="22" cy="44" r="3" fill="#a855f7" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="28" y1="44" x2="38" y2="44" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  ),

  Quizlet: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="12" y="10" width="40" height="44" rx="6" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <rect x="16" y="14" width="32" height="36" rx="3" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <path d="M35 18L24 33H33L29 46L42 29H33L35 18Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="2.5" strokeLinejoin="round" />
    </svg>
  ),

  CanvaProject: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M32 8C18.7 8 8 18.7 8 32C8 45.3 18.7 56 32 56C36.4 56 40 52.4 40 48C40 46 39.2 44.2 37.8 42.8C36.4 41.4 35.6 39.6 35.6 37.6C35.6 33.2 39.2 29.6 43.6 29.6H48C52.4 29.6 56 26 56 21.6C56 14.1 45.3 8 32 8Z" 
        fill="#fed7aa" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <circle cx="20" cy="24" r="4.5" fill="#f43f5e" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="32" cy="18" r="4.5" fill="#38bdf8" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="44" cy="22" r="4.5" fill="#34d399" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="22" cy="38" r="4.5" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <path d="M42 42L56 56" stroke="#1e293b" strokeWidth="4" strokeLinecap="round" />
      <path d="M40 40L46 46" stroke="#38bdf8" strokeWidth="3" strokeLinecap="round" />
    </svg>
  ),

  Laptop: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="12" y="12" width="40" height="28" rx="3" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <rect x="16" y="16" width="32" height="20" rx="1.5" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="32" cy="26" r="4" fill="#fbbf24" />
      <path d="M6 42H58L54 50H10L6 42Z" fill="#cbd5e1" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <line x1="28" y1="46" x2="36" y2="46" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),

  Tablet: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="12" y="8" width="40" height="48" rx="6" fill="#818cf8" stroke="#1e293b" strokeWidth="3" />
      <rect x="16" y="14" width="32" height="36" rx="2" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="32" cy="52.5" r="1.5" fill="#ffffff" />
      <rect x="20" y="20" width="10" height="10" rx="2" fill="#fbbf24" />
      <rect x="34" y="20" width="10" height="10" rx="2" fill="#f43f5e" />
      <rect x="20" y="34" width="10" height="10" rx="2" fill="#34d399" />
      <rect x="34" y="34" width="10" height="10" rx="2" fill="#38bdf8" />
    </svg>
  ),

  Bot: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="14" y="16" width="36" height="32" rx="8" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <path d="M32 8V16" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
      <circle cx="32" cy="8" r="3" fill="#f43f5e" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="24" cy="28" r="4" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="40" cy="28" r="4" fill="#ffffff" stroke="#1e293b" strokeWidth="2" />
      <circle cx="24" cy="28" r="1.5" fill="#1e293b" />
      <circle cx="40" cy="28" r="1.5" fill="#1e293b" />
      <rect x="24" y="38" width="16" height="4" rx="2" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
      <path d="M8 28H14M50 28H56" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
    </svg>
  ),

  Globe: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <circle cx="32" cy="32" r="22" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <path d="M12 24C16 26 22 22 26 26C30 30 26 36 32 38C38 40 44 32 50 34" fill="#34d399" stroke="#1e293b" strokeWidth="2" />
      <path d="M16 42C20 44 26 42 30 48C34 54 28 54 28 54" fill="#34d399" stroke="#1e293b" strokeWidth="2" />
      <path d="M32 10C32 10 42 16 44 22" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),

  // 7. GAMES & CHALLENGES
  Challenge: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M32 6C32 6 38 16 38 22C38 26 36 28 34 30C38 30 46 26 46 36C46 47 38 56 30 56C18 56 12 46 12 36C12 24 22 14 32 6Z" 
        fill="#f43f5e" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M30 24C30 24 34 30 34 34C34 36 32 38 31 39C34 39 38 36 38 42C38 48 34 52 29 52C22 52 18 46 18 40C18 32 24 28 30 24Z" 
        fill="#fbbf24" stroke="#1e293b" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  ),

  FinalTask: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M18 12H46V28C46 36 39.7 42 32 42C24.3 42 18 36 18 28V12Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M18 16H10C7.8 16 6 17.8 6 20V24C6 28.4 9.6 32 14 32H18" stroke="#1e293b" strokeWidth="3" fill="none" />
      <path d="M46 16H54C56.2 16 58 17.8 58 20V24C58 28.4 54.4 32 50 32H46" stroke="#1e293b" strokeWidth="3" fill="none" />
      <polygon points="32,20 34,25 39,25 35,28 37,33 32,30 27,33 29,28 25,25 30,25" fill="#ffffff" stroke="#1e293b" strokeWidth="1.5" />
      <path d="M32 42V50M22 50H42V58H22V50Z" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
    </svg>
  ),

  Project: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="10" y="20" width="44" height="34" rx="4" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <path d="M10 28H54" stroke="#1e293b" strokeWidth="2.5" />
      <path d="M22 10L42 30" stroke="#f43f5e" strokeWidth="5" strokeLinecap="round" />
      <path d="M42 10L22 30" stroke="#fbbf24" strokeWidth="4" strokeLinecap="round" />
      <circle cx="32" cy="42" r="5" fill="#34d399" stroke="#1e293b" strokeWidth="2" />
    </svg>
  ),

  Game: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <rect x="8" y="16" width="30" height="30" rx="6" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <circle cx="16" cy="24" r="3" fill="#ffffff" />
      <circle cx="23" cy="31" r="3" fill="#ffffff" />
      <circle cx="30" cy="38" r="3" fill="#ffffff" />
      <rect x="28" y="8" width="28" height="28" rx="6" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" />
      <circle cx="36" cy="16" r="2.5" fill="#1e293b" />
      <circle cx="48" cy="28" r="2.5" fill="#1e293b" />
    </svg>
  ),

  Review: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <circle cx="32" cy="32" r="22" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <circle cx="32" cy="32" r="15" fill="#ffffff" stroke="#1e293b" strokeWidth="2.5" />
      <circle cx="32" cy="32" r="8" fill="#38bdf8" stroke="#1e293b" strokeWidth="2" />
      <circle cx="32" cy="32" r="3" fill="#fbbf24" />
      <circle cx="48" cy="18" r="8" fill="#34d399" stroke="#1e293b" strokeWidth="2.5" />
      <path d="M44 18L47 21L52 15" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),

  ExitTicket: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M10 18C10 18 10 26 16 26C22 26 22 18 22 18H54V46H22C22 46 22 38 16 38C10 38 10 46 10 46V18Z" 
        fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <line x1="28" y1="18" x2="28" y2="46" stroke="#1e293b" strokeWidth="2" strokeDasharray="3 3" />
      <polygon points="42,26 44,30 49,30 45,33 47,38 42,35 37,38 39,33 35,30 40,30" fill="#f43f5e" stroke="#1e293b" strokeWidth="1.5" />
    </svg>
  ),

  Trophy: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M18 14H46V28C46 36 40 42 32 42C24 42 18 36 18 28V14Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" />
      <path d="M18 18H10C8 18 6 20 6 22V26C6 30 10 34 14 34H18" stroke="#1e293b" strokeWidth="3" fill="none" />
      <path d="M46 18H54C56 18 58 20 58 22V26C58 30 54 34 50 34H46" stroke="#1e293b" strokeWidth="3" fill="none" />
      <path d="M32 42V50M22 50H42V56H22V50Z" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
    </svg>
  ),

  Award: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <circle cx="32" cy="26" r="16" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" />
      <polygon points="32,18 34,22 38,22 35,25 36,29 32,27 28,29 29,25 26,22 30,22" fill="#ffffff" stroke="#1e293b" strokeWidth="1" />
      <path d="M24 38L20 54L30 48L32 50L34 48L44 54L40 38" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
    </svg>
  ),

  Sparkles: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M32 6L36 22L52 26L36 30L32 46L28 30L12 26L28 22L32 6Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M48 40L50 46L56 48L50 50L48 56L46 50L40 48L46 46L48 40Z" fill="#38bdf8" stroke="#1e293b" strokeWidth="2" strokeLinejoin="round" />
      <circle cx="16" cy="46" r="3" fill="#f43f5e" stroke="#1e293b" strokeWidth="1.5" />
    </svg>
  ),

  GraduationCap: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <polygon points="32,10 60,22 32,34 4,22" fill="#818cf8" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M16 28V42C16 46 23 50 32 50C41 50 48 46 48 42V28" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <path d="M52 26V44L56 46" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" />
      <circle cx="56" cy="48" r="3" fill="#fbbf24" stroke="#1e293b" strokeWidth="1.5" />
    </svg>
  ),

  Crown: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M8 48L12 20L24 32L32 14L40 32L52 20L56 48H8Z" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <circle cx="12" cy="18" r="3" fill="#f43f5e" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="32" cy="12" r="3.5" fill="#38bdf8" stroke="#1e293b" strokeWidth="1.5" />
      <circle cx="52" cy="18" r="3" fill="#34d399" stroke="#1e293b" strokeWidth="1.5" />
      <line x1="12" y1="42" x2="52" y2="42" stroke="#1e293b" strokeWidth="2.5" />
    </svg>
  ),

  Scissors: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <circle cx="18" cy="46" r="8" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <circle cx="46" cy="46" r="8" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <circle cx="18" cy="46" r="4" fill="#ffffff" />
      <circle cx="46" cy="46" r="4" fill="#ffffff" />
      <path d="M24 40L48 10" stroke="#cbd5e1" strokeWidth="5" strokeLinecap="round" />
      <path d="M40 40L16 10" stroke="#cbd5e1" strokeWidth="5" strokeLinecap="round" />
      <circle cx="32" cy="30" r="3" fill="#fbbf24" stroke="#1e293b" strokeWidth="2" />
    </svg>
  ),

  Brush: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M44 8L56 20L34 42L22 30L44 8Z" fill="#fed7aa" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M22 30L34 42L28 48L16 36L22 30Z" fill="#cbd5e1" stroke="#1e293b" strokeWidth="3" />
      <path d="M16 36L28 48C28 48 24 58 14 58C14 48 16 36 16 36Z" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
    </svg>
  ),

  Brain: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <path d="M24 16C18 16 14 20 14 26C10 28 8 33 8 38C8 44 13 49 19 49C21 51 25 53 30 53H34C39 53 43 51 45 49C51 49 56 44 56 38C56 33 54 28 50 26C50 20 46 16 40 16C37 12 27 12 24 16Z" 
        fill="#f472b6" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M32 16V50M22 28C26 30 26 36 22 40M42 28C38 30 38 36 42 40" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  ),

  PartyPopper: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <polygon points="12,52 38,42 22,16" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
      <path d="M17 34L30 29" stroke="#f43f5e" strokeWidth="3" />
      <path d="M14 43L34 35" stroke="#38bdf8" strokeWidth="3" />
      <circle cx="44" cy="18" r="3" fill="#f43f5e" />
      <circle cx="52" cy="30" r="3" fill="#34d399" />
      <circle cx="38" cy="10" r="2.5" fill="#38bdf8" />
      <rect x="48" y="10" width="4" height="4" rx="1" fill="#c084fc" transform="rotate(25 50 12)" />
    </svg>
  ),

  Shapes: ({ className, size = 64 }) => (
    <svg {...defaultProps} width={size} height={size} className={className}>
      <circle cx="20" cy="22" r="10" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
      <rect x="34" y="12" width="20" height="20" rx="3" fill="#38bdf8" stroke="#1e293b" strokeWidth="3" />
      <polygon points="32,36 50,56 14,56" fill="#fbbf24" stroke="#1e293b" strokeWidth="3" strokeLinejoin="round" />
    </svg>
  )
};

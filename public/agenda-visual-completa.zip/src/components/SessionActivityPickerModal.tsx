import React, { useState, useMemo } from 'react';
import { Activity, ActivityType } from '../types';
import { ActivityIconBadge } from './IconRenderer';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Search, 
  Check, 
  Plus, 
  Layers, 
  Sparkles, 
  CheckCheck, 
  RotateCcw,
  BookOpen,
  ArrowRight
} from 'lucide-react';
import { cn } from '../lib/utils';

interface SessionActivityPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  gradeActivities: Activity[];
  activityTypes: ActivityType[];
  currentGradeName: string;
  currentSequence: Activity[];
  onAddActivities: (activitiesToAdd: Activity[]) => void;
  onCreateNewActivity: () => void;
}

export function SessionActivityPickerModal({
  isOpen,
  onClose,
  gradeActivities,
  activityTypes,
  currentGradeName,
  currentSequence,
  onAddActivities,
  onCreateNewActivity
}: SessionActivityPickerModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTypeId, setSelectedTypeId] = useState<string>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Count how many times each activity is already in the today's sequence
  const sequenceCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    currentSequence.forEach(item => {
      // If the sequence item carries the original bank activity ID or name match
      counts[item.id] = (counts[item.id] || 0) + 1;
      if (item.name) {
        counts[item.name] = (counts[item.name] || 0) + 1;
      }
    });
    return counts;
  }, [currentSequence]);

  // Build dynamic type categories from activities existing in this grade
  const availableTypesWithCount = useMemo(() => {
    const typeMap = new Map<string, { type: ActivityType; count: number }>();

    gradeActivities.forEach(activity => {
      if (activity.typeId) {
        const foundType = activityTypes.find(t => t.id === activity.typeId);
        if (foundType) {
          const current = typeMap.get(foundType.id);
          if (current) {
            current.count += 1;
          } else {
            typeMap.set(foundType.id, { type: foundType, count: 1 });
          }
        }
      }
    });

    return Array.from(typeMap.values());
  }, [gradeActivities, activityTypes]);

  // Filter activities based on search and type filter
  const filteredActivities = useMemo(() => {
    return gradeActivities.filter(activity => {
      // 1. Type filter
      if (selectedTypeId !== 'all') {
        if (activity.typeId !== selectedTypeId) return false;
      }

      // 2. Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = activity.name.toLowerCase().includes(query);
        const matchesDesc = activity.description?.toLowerCase().includes(query);
        const typeObj = activityTypes.find(t => t.id === activity.typeId);
        const matchesType = typeObj?.name.toLowerCase().includes(query);
        return matchesName || matchesDesc || matchesType;
      }

      return true;
    });
  }, [gradeActivities, selectedTypeId, searchQuery, activityTypes]);

  const toggleSelect = (activityId: string) => {
    setSelectedIds(prev => 
      prev.includes(activityId) 
        ? prev.filter(id => id !== activityId)
        : [...prev, activityId]
    );
  };

  const handleSelectAll = () => {
    const allFilteredIds = filteredActivities.map(a => a.id);
    const newSelected = Array.from(new Set([...selectedIds, ...allFilteredIds]));
    setSelectedIds(newSelected);
  };

  const handleClearSelection = () => {
    setSelectedIds([]);
  };

  const handleConfirmAdd = () => {
    if (selectedIds.length === 0) return;

    // Get selected activity objects in the order of selection or bank order
    const activitiesToAdd = selectedIds
      .map(id => gradeActivities.find(a => a.id === id))
      .filter((a): a is Activity => !!a);

    onAddActivities(activitiesToAdd);
    setSelectedIds([]);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 md:p-6 overflow-hidden">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
        />

        {/* Modal Window (Fullscreen on Mobile/Tablet, Spacious Centered Modal on Desktop) */}
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 15 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="bg-white w-full h-full sm:h-auto sm:max-h-[92vh] sm:max-w-4xl sm:rounded-[2.5rem] shadow-2xl relative z-10 overflow-hidden flex flex-col border border-slate-100"
        >
          {/* Top Bar Header */}
          <div className="px-5 py-4 sm:px-8 sm:py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-50 via-white to-blue-50/40 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black shadow-md shadow-blue-200 shrink-0">
                <Layers size={24} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-black uppercase tracking-wider bg-blue-100 text-blue-700">
                    {currentGradeName}
                  </span>
                  <span className="text-xs font-bold text-slate-400">
                    Banco de Actividades
                  </span>
                </div>
                <h3 className="text-lg sm:text-2xl font-black text-slate-800 tracking-tight mt-0.5">
                  Añadir actividades a la sesión
                </h3>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2.5 hover:bg-slate-200/70 text-slate-400 hover:text-slate-700 rounded-full transition-colors active:scale-95"
              title="Cerrar ventana"
            >
              <X size={24} />
            </button>
          </div>

          {/* Search Bar & Type Filter Bar */}
          <div className="px-5 py-3.5 sm:px-8 sm:py-4 bg-slate-50/70 border-b border-slate-100 shrink-0 space-y-3">
            {/* Search Input and Quick Actions */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={`Buscar en ${gradeActivities.length} actividades de ${currentGradeName}...`}
                  className="w-full pl-10 pr-9 py-3 rounded-2xl border-2 border-slate-200 focus:border-blue-500 focus:bg-white focus:outline-none font-bold text-slate-800 text-sm bg-white shadow-xs transition-all"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
                  >
                    <X size={15} />
                  </button>
                )}
              </div>

              {/* Selection Shortcuts */}
              <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                <button
                  type="button"
                  onClick={handleSelectAll}
                  disabled={filteredActivities.length === 0}
                  className="px-3.5 py-2.5 rounded-xl border border-slate-200 hover:border-blue-300 bg-white hover:bg-blue-50 text-slate-600 hover:text-blue-700 text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 disabled:opacity-40 disabled:pointer-events-none"
                >
                  <CheckCheck size={15} />
                  <span>Seleccionar visibles</span>
                </button>
                {selectedIds.length > 0 && (
                  <button
                    type="button"
                    onClick={handleClearSelection}
                    className="px-3 py-2.5 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-600 text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                  >
                    <RotateCcw size={14} />
                    <span>Limpiar</span>
                  </button>
                )}
              </div>
            </div>

            {/* Dynamic Type Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
              <button
                type="button"
                onClick={() => setSelectedTypeId('all')}
                className={cn(
                  "px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all select-none flex items-center gap-1.5",
                  selectedTypeId === 'all'
                    ? "bg-slate-800 text-white shadow-xs scale-102 font-black"
                    : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-100"
                )}
              >
                <span>Todos</span>
                <span className={cn(
                  "px-1.5 py-0.2 rounded-full text-[10px] font-black",
                  selectedTypeId === 'all' ? "bg-white/20 text-white" : "bg-slate-100 text-slate-500"
                )}>
                  {gradeActivities.length}
                </span>
              </button>

              {availableTypesWithCount.map(({ type, count }) => (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => setSelectedTypeId(type.id)}
                  className={cn(
                    "px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all select-none flex items-center gap-1.5",
                    selectedTypeId === type.id
                      ? "bg-blue-600 text-white shadow-xs scale-102 font-black"
                      : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-100"
                  )}
                >
                  <span>{type.name}</span>
                  <span className={cn(
                    "px-1.5 py-0.2 rounded-full text-[10px] font-black",
                    selectedTypeId === type.id ? "bg-white/20 text-white" : "bg-slate-100 text-slate-500"
                  )}>
                    {count}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Activities Grid */}
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-slate-50/40">
            {gradeActivities.length === 0 ? (
              <div className="py-16 px-4 flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 rounded-3xl bg-blue-100 text-blue-600 flex items-center justify-center mb-4">
                  <BookOpen size={32} />
                </div>
                <h4 className="font-black text-lg text-slate-800 mb-1">
                  El banco de {currentGradeName} está vacío
                </h4>
                <p className="text-xs text-slate-400 max-w-sm mb-6">
                  Crea actividades para este curso para poder utilizarlas y reutilizarlas en tus sesiones de clase.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onCreateNewActivity();
                  }}
                  className="px-6 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-sm rounded-2xl shadow-md flex items-center gap-2 active:scale-95 transition-all"
                >
                  <Plus size={18} />
                  <span>Crear primera actividad para {currentGradeName}</span>
                </button>
              </div>
            ) : filteredActivities.length === 0 ? (
              <div className="py-16 px-4 flex flex-col items-center justify-center text-center text-slate-400">
                <Search size={40} className="mb-3 opacity-30 text-slate-400" />
                <p className="font-bold text-sm text-slate-600">No se encontraron actividades</p>
                <p className="text-xs text-slate-400 mt-1">
                  Prueba cambiando los términos de búsqueda o el filtro de tipo.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-3.5">
                {filteredActivities.map(activity => {
                  const isSelected = selectedIds.includes(activity.id);
                  const matchedType = activity.typeId 
                    ? activityTypes.find(t => t.id === activity.typeId)
                    : undefined;
                  const alreadyInSeqCount = sequenceCounts[activity.id] || sequenceCounts[activity.name] || 0;

                  return (
                    <div
                      key={activity.id}
                      onClick={() => toggleSelect(activity.id)}
                      className={cn(
                        "relative p-3.5 sm:p-4 rounded-2xl sm:rounded-3xl border-2 transition-all cursor-pointer select-none flex items-center gap-3.5 group min-h-[84px]",
                        isSelected
                          ? "bg-blue-50/80 border-blue-500 shadow-md ring-2 ring-blue-400/30 scale-[1.01]"
                          : "bg-white border-slate-100/90 hover:border-blue-200 hover:shadow-sm"
                      )}
                    >
                      {/* Chunky Icon with 75-80% drawing occupancy */}
                      <div className="relative shrink-0">
                        <ActivityIconBadge 
                          icon={activity.icon}
                          customImage={activity.customImage}
                          colorClass={activity.color}
                          size="md"
                          className={cn(
                            "transition-transform",
                            isSelected ? "scale-105" : "group-hover:scale-105"
                          )}
                        />
                      </div>

                      {/* Info & Labels */}
                      <div className="min-w-0 flex-1 pr-7">
                        <div className="flex items-center gap-1.5 flex-wrap mb-1">
                          {matchedType && (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-slate-100 text-slate-600 border border-slate-200/80 truncate max-w-[140px]">
                              {matchedType.name}
                            </span>
                          )}
                          {alreadyInSeqCount > 0 && (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200/80">
                              En sesión {alreadyInSeqCount > 1 ? `(x${alreadyInSeqCount})` : '✓'}
                            </span>
                          )}
                        </div>

                        <h4 className="font-black text-sm text-slate-800 leading-snug line-clamp-2">
                          {activity.name}
                        </h4>

                        {activity.description && (
                          <p className="text-[11px] font-medium text-slate-400 truncate mt-0.5">
                            {activity.description}
                          </p>
                        )}
                      </div>

                      {/* Selection Checkbox Pill */}
                      <div className={cn(
                        "absolute top-3.5 right-3.5 w-6 h-6 rounded-full flex items-center justify-center transition-all border-2",
                        isSelected
                          ? "bg-blue-600 border-blue-600 text-white shadow-xs scale-110"
                          : "border-slate-300 bg-white group-hover:border-blue-400"
                      )}>
                        {isSelected && <Check size={14} strokeWidth={3.5} />}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Sticky Bottom Footer */}
          <div className="px-5 py-4 sm:px-8 sm:py-5 border-t border-slate-100 bg-white flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0 shadow-lg">
            <div className="flex items-center justify-between w-full sm:w-auto gap-3">
              <div className="flex items-center gap-2">
                <span className={cn(
                  "w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs transition-colors",
                  selectedIds.length > 0 ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-500"
                )}>
                  {selectedIds.length}
                </span>
                <span className="text-xs sm:text-sm font-bold text-slate-700">
                  {selectedIds.length === 1 
                    ? '1 actividad seleccionada' 
                    : `${selectedIds.length} actividades seleccionadas`}
                </span>
              </div>

              {/* Mobile shortcut to cancel */}
              <button
                type="button"
                onClick={onClose}
                className="sm:hidden text-xs font-bold text-slate-400 hover:text-slate-600 px-2 py-1"
              >
                Cancelar
              </button>
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="hidden sm:block px-5 py-3.5 rounded-2xl text-slate-500 hover:bg-slate-100 font-bold text-sm transition-all"
              >
                Cancelar
              </button>

              <button
                type="button"
                onClick={handleConfirmAdd}
                disabled={selectedIds.length === 0}
                className={cn(
                  "flex-1 sm:flex-initial px-8 py-3.5 sm:py-4 rounded-2xl font-black text-sm sm:text-base text-white shadow-lg transition-all flex items-center justify-center gap-2.5 active:scale-95",
                  selectedIds.length > 0
                    ? "bg-blue-600 hover:bg-blue-700 shadow-blue-200"
                    : "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none"
                )}
              >
                <Plus size={18} strokeWidth={3} />
                <span>
                  {selectedIds.length > 0 
                    ? `Añadir ${selectedIds.length} a la sesión` 
                    : 'Añadir a la sesión'}
                </span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
